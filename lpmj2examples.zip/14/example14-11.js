<script>
onerror = errorHandler
document.writ("Welcome to this website") // Deliberate error

function errorHandler(message, url, line)
{
	out  = "Sorry, an error was encountered.\n\n";
	out += "Error: " + message + "\n";
	out += "URL: "   + url + "\n";
	out += "Line: "  + line + "\n\n";
	out += "Click OK to continue.\n\n";
	alert(out);
	return true;
}
</script>