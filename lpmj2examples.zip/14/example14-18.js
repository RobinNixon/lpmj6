<script>
count = 1
do
{
	document.write(count + " times 7 is " + count * 7 + "<br />")
} while (++count <= 7)
</script>