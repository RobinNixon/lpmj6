<script>
switch (page)
{
	case "Home":  document.write("You selected Home")
		break
	case "About": document.write("You selected About")
		break
	case "News":  document.write("You selected News")
		break
	case "Login": document.write("You selected Login")
		break
	case "Links": document.write("You selected Links")
		break
}
</script>