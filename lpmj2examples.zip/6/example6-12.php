<?php
$temp = explode(' ', "This is a sentence with seven words");
print_r($temp);
?>
