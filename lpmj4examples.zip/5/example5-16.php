<?php
  class User
  {
    function __destruct()
    {
      // Destructor code goes here
    }
  }
?>
