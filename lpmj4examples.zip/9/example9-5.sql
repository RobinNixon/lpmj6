ROLLBACK;
SELECT * FROM accounts;
