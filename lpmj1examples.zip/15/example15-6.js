<script>
a = 7; b = 11
if (a > b)  document.write("a is greater than b<br />")
if (a < b)  document.write("a is less than b<br />")
if (a >= b) document.write("a is greater than or equal to b<br />")
if (a <= b) document.write("a is less than or equal to b<br />")
</script>