<script>
month = "July"
if (month == "October") document.write("It's the fall")
</script>