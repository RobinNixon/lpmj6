<script>
try
{
	request = new XMLHTTPRequest()
}
catch(err)
{
	// Use a different method to create an XML HTTP Request object
}
</script>