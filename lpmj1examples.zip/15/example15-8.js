<script>
if (finished == 1 || getnext() == 1) done = 1
</script>