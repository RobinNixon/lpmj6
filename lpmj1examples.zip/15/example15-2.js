<script>
myname = "Peter"
myage  = 24
document.write("a: " + 42     + "<br />") // Numeric literal
document.write("b: " + "Hi"   + "<br />") // String literal
document.write("c: " + true   + "<br />") // Constant literal
document.write("d: " + myname + "<br />") // Variable string literal
document.write("e: " + myage  + "<br />") // Variable numeric literal
</script>