<?php
$myname = "Brian";
$myage = 37;
echo "a: " . 73      . "<br />"; // Numeric literal
echo "b: " . "Hello" . "<br />"; // String literal
echo "c: " . FALSE   . "<br />"; // Constant literal
echo "d: " . $myname . "<br />"; // Variable string literal
echo "e: " . $myage  . "<br />"; // Variable numeric literal
?>
