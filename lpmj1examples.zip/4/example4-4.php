<?php
$days_to_new_year = 366 - $day_number; // Expression
if ($days_to_new_year < 30)
	echo "Not long now till new year"; // Statement
?>
