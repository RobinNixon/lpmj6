<?php
$fuel = 10;

while ($fuel > 1)
{
	// Keep driving �
	echo "There's enough fuel";
}
?>
