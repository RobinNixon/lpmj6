<?php // index.php
include_once 'rnheader.php';

echo "<h3>Home page</h3>
	  Welcome, please Sign up and/or Log in to join in.";
?>