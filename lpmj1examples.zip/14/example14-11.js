<script>
function isset(varname)
{
	return typeof varname != 'undefined'
}
</script>
