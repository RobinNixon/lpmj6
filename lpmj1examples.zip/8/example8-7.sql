ALTER TABLE classics DROP id;
