<?php
$names = array();
echo sizeof($names) . "<br />";
$names[] = 'Bob';
echo count($names) . "<br />";  // count is an alias of sizeof
?>
