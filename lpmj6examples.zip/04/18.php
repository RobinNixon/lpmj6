<?php
  $gn = getnext();

  if ($finished == 1 or $gn == 1) exit;
?>
